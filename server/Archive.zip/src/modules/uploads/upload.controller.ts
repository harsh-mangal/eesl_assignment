import type { Request, Response } from 'express';
import { ApiError } from '../../utils/api-error.js';
import * as memberService from '../members/member.service.js';
import * as roomService from '../rooms/room.service.js';
import * as eventService from '../events/event.service.js';
import { deleteManagedImage, storeImage } from './upload.service.js';


function requestPublicBaseUrl(request: Request) {
  if (process.env.NODE_ENV === 'production') return undefined;
  const forwardedProtocol = request.header('x-forwarded-proto')?.split(',')[0]?.trim();
  const protocol = forwardedProtocol || request.protocol;
  const host = request.header('x-forwarded-host')?.split(',')[0]?.trim() || request.get('host');
  return host ? `${protocol}://${host}` : undefined;
}

function requireMemberId(request: Request) {
  if (!request.auth?.memberId) throw new ApiError(403, 'Member account is required.');
  return request.auth.memberId;
}

async function replaceAndRespond<T>(
  request: Request,
  response: Response,
  folder: string,
  update: (url: string) => Promise<{ data: T; previousUrl?: string | null }>,
  message: string,
) {
  const stored = await storeImage(request.file, folder, requestPublicBaseUrl(request));
  try {
    const result = await update(stored.url);
    await deleteManagedImage(result.previousUrl);
    return response.status(200).json({
      success: true,
      message,
      data: result.data,
      upload: {
        provider: stored.provider,
        mimeType: stored.mimeType,
        size: stored.size,
      },
    });
  } catch (error) {
    await deleteManagedImage(stored.url);
    throw error;
  }
}

export async function ownProfilePhoto(request: Request, response: Response) {
  return replaceAndRespond(
    request,
    response,
    'members',
    (url) => memberService.replaceProfilePhoto(requireMemberId(request), url),
    'Profile photo updated.',
  );
}

export async function adminMemberPhoto(request: Request, response: Response) {
  return replaceAndRespond(
    request,
    response,
    'members',
    (url) => memberService.replaceProfilePhoto(String(request.params.id), url),
    'Member photo updated.',
  );
}

export async function roomImage(request: Request, response: Response) {
  return replaceAndRespond(
    request,
    response,
    'rooms',
    (url) => roomService.replaceRoomImage(String(request.params.id), url),
    'Room image updated.',
  );
}

export async function eventBanner(request: Request, response: Response) {
  return replaceAndRespond(
    request,
    response,
    'events',
    (url) => eventService.replaceEventBanner(String(request.params.id), url),
    'Event banner updated.',
  );
}
