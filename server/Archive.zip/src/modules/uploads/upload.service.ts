import { v2 as cloudinary } from 'cloudinary';
import { randomUUID } from 'node:crypto';
import { mkdir, unlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { env } from '../../config/env.js';
import { ApiError } from '../../utils/api-error.js';

const mimeExtensions: Record<string, string> = {
  'image/jpeg': '.jpg',
  'image/png': '.png',
  'image/webp': '.webp',
};

if (env.UPLOAD_PROVIDER === 'cloudinary') {
  cloudinary.config({
    cloud_name: env.CLOUDINARY_CLOUD_NAME,
    api_key: env.CLOUDINARY_API_KEY,
    api_secret: env.CLOUDINARY_API_SECRET,
    secure: true,
  });
}

export type StoredImage = {
  url: string;
  provider: 'local' | 'cloudinary';
  publicId: string;
  mimeType: string;
  size: number;
};


function detectImageMime(buffer: Buffer) {
  if (buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) {
    return 'image/png';
  }
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return 'image/jpeg';
  }
  if (buffer.length >= 12 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP') {
    return 'image/webp';
  }
  return null;
}

function verifiedImage(file: Express.Multer.File) {
  const detectedMime = detectImageMime(file.buffer);
  if (!detectedMime) throw new ApiError(415, 'The uploaded file is not a valid JPEG, PNG or WebP image.');
  if (detectedMime !== file.mimetype) {
    throw new ApiError(415, 'The image content does not match its declared file type.');
  }
  return { ...file, mimetype: detectedMime };
}

function safeFolder(folder: string) {
  const normalized = folder.replace(/[^a-z0-9/_-]/gi, '').replace(/^\/+|\/+$/g, '');
  if (!normalized) throw new ApiError(500, 'Upload folder configuration is invalid.');
  return normalized;
}

function uploadRoot() {
  return path.resolve(process.cwd(), env.UPLOAD_DIR);
}

function localPublicUrl(relativePath: string, publicBaseUrl = env.PUBLIC_BASE_URL) {
  const normalizedBase = publicBaseUrl.replace(/\/$/, '');
  return `${normalizedBase}/uploads/${relativePath.split(path.sep).join('/')}`;
}

async function storeLocal(file: Express.Multer.File, folder: string, publicBaseUrl?: string): Promise<StoredImage> {
  const extension = mimeExtensions[file.mimetype];
  if (!extension) throw new ApiError(415, 'Unsupported image type.');

  const safeDirectory = safeFolder(folder);
  const fileName = `${Date.now()}-${randomUUID()}${extension}`;
  const relativePath = path.join(safeDirectory, fileName);
  const absoluteDirectory = path.join(uploadRoot(), safeDirectory);
  const absolutePath = path.join(uploadRoot(), relativePath);

  await mkdir(absoluteDirectory, { recursive: true });
  await writeFile(absolutePath, file.buffer, { flag: 'wx' });

  return {
    url: localPublicUrl(relativePath, publicBaseUrl),
    provider: 'local',
    publicId: relativePath.split(path.sep).join('/'),
    mimeType: file.mimetype,
    size: file.size,
  };
}

async function storeCloudinary(file: Express.Multer.File, folder: string): Promise<StoredImage> {
  if (!env.CLOUDINARY_CLOUD_NAME || !env.CLOUDINARY_API_KEY || !env.CLOUDINARY_API_SECRET) {
    throw new ApiError(500, 'Cloudinary upload credentials are incomplete.');
  }

  const targetFolder = `${env.CLOUDINARY_FOLDER.replace(/\/$/, '')}/${safeFolder(folder)}`;
  const result = await new Promise<{ secure_url: string; public_id: string }>((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(
      {
        folder: targetFolder,
        resource_type: 'image',
        unique_filename: true,
        overwrite: false,
        transformation: [{ quality: 'auto', fetch_format: 'auto' }],
      },
      (error, uploadResult) => {
        if (error || !uploadResult) return reject(error ?? new Error('Cloudinary upload failed.'));
        return resolve(uploadResult);
      },
    );
    stream.end(file.buffer);
  });

  return {
    url: result.secure_url,
    provider: 'cloudinary',
    publicId: result.public_id,
    mimeType: file.mimetype,
    size: file.size,
  };
}

export async function storeImage(file: Express.Multer.File | undefined, folder: string, publicBaseUrl?: string) {
  if (!file) throw new ApiError(422, 'Please select an image to upload.');
  const verified = verifiedImage(file);
  return env.UPLOAD_PROVIDER === 'cloudinary'
    ? storeCloudinary(verified, folder)
    : storeLocal(verified, folder, publicBaseUrl);
}

function extractLocalRelativePath(url: string) {
  try {
    const parsed = new URL(url, env.PUBLIC_BASE_URL);
    const marker = '/uploads/';
    const markerIndex = parsed.pathname.indexOf(marker);
    if (markerIndex === -1) return null;
    const decoded = decodeURIComponent(parsed.pathname.slice(markerIndex + marker.length));
    const normalized = path.normalize(decoded).replace(/^(\.\.(\/|\\|$))+/, '');
    const absolute = path.resolve(uploadRoot(), normalized);
    if (!absolute.startsWith(`${uploadRoot()}${path.sep}`)) return null;
    return absolute;
  } catch {
    return null;
  }
}

function extractCloudinaryPublicId(url: string) {
  try {
    const parsed = new URL(url);
    if (parsed.hostname !== 'res.cloudinary.com') return null;
    const marker = '/upload/';
    const markerIndex = parsed.pathname.indexOf(marker);
    if (markerIndex === -1) return null;
    const afterUpload = parsed.pathname.slice(markerIndex + marker.length).replace(/^v\d+\//, '');
    const publicId = afterUpload.replace(/\.[a-z0-9]+$/i, '');
    return publicId.startsWith(`${env.CLOUDINARY_FOLDER.replace(/\/$/, '')}/`) ? publicId : null;
  } catch {
    return null;
  }
}

export async function deleteManagedImage(url?: string | null) {
  if (!url) return;

  try {
    if (env.UPLOAD_PROVIDER === 'local') {
      const absolutePath = extractLocalRelativePath(url);
      if (absolutePath) await unlink(absolutePath).catch(() => undefined);
      return;
    }

    const publicId = extractCloudinaryPublicId(url);
    if (publicId) await cloudinary.uploader.destroy(publicId, { invalidate: true, resource_type: 'image' });
  } catch (error) {
    console.warn('Unable to delete replaced upload:', error);
  }
}
