import multer from 'multer';
import { env } from '../../config/env.js';
import { ApiError } from '../../utils/api-error.js';

const allowedMimeTypes = new Set(['image/jpeg', 'image/png', 'image/webp']);

export const imageUpload = multer({
  storage: multer.memoryStorage(),
  limits: {
    files: 1,
    fileSize: env.MAX_UPLOAD_MB * 1024 * 1024,
  },
  fileFilter: (_request, file, callback) => {
    if (!allowedMimeTypes.has(file.mimetype)) {
      return callback(new ApiError(415, 'Only JPEG, PNG and WebP images are allowed.'));
    }
    return callback(null, true);
  },
}).single('image');
